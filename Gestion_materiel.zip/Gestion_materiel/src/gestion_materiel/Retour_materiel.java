package gestion_materiel;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import net.proteanit.sql.DbUtils;

import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;

import javax.swing.JComboBox;
import javax.swing.JFileChooser;

import com.toedter.calendar.JDateChooser;
import java.awt.Color;

public class Retour_materiel extends JFrame {

	private JPanel contentPane;
	String userold= null;
	private String s;

	//Creation des 3 objets de type Connection
		Connection cnx=null; // poyr établir la BD
		PreparedStatement prepared= null; //pr exécuter une requête	 
		ResultSet resultat= null; //récupération des infos de BD
		private JTable table;
		private JTextField mat1;
		//méthode pour fermer une fenêtre
		void fermer() {
			dispose();
		}
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Retour_materiel frame = new  Retour_materiel();
					frame.setVisible(true);
					//fixer la fenetre à la mm taille d'autres fenetres
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public  Retour_materiel() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1000, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		//établissement de la connexion DB
		cnx= connexionMysql.ConnexionDB();
	
		
		JLabel mat = new JLabel("Séléctionnez le matériel concerné:");
		mat.setBounds(48, 141, 274, 32);
		contentPane.add(mat);
		
		JButton btnNewButton = new JButton(" Exécuter");
		btnNewButton.setIcon(new ImageIcon("/home/zaki/eclipse-workspace/Gestion_materiel/images/ok/execute.png"));
		btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				//String mat_box id_usr_box
			//		date_empr_box date_r_box duree_empr_box
					int ligne = table.getSelectedRow();
					String id=table.getModel().getValueAt(ligne, 0).toString();
					String sql="delete from Emprunt where id_emprunt='"+id+"'";
					
					//String sql= "insert into Emprunt (id_user,id_materiel_a_empr,date_prendre,date_rendre,duree_reserv) values (?,?,?,?,?)";
					try {
						prepared=cnx.prepareStatement(sql);
						prepared.execute();
						JOptionPane.showMessageDialog(null, "Le retour du matériel a bien été enregistré dans la base. 😜");
						
						mat1.setText("");
						UpdateTable();
						
					}
						 
					catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				}
					//String sql="insert into utilisateurs(username,nom,prenom,email,password) values (?, ?, ?, ?, ?)"; // réquete insert
			
		
		});
		
		JLabel lblNewLabel_1 = new JLabel("Les emprunts:");
		lblNewLabel_1.setFont(new Font("Khmer OS System", Font.BOLD, 18));
		lblNewLabel_1.setBounds(389, 74, 211, 45);
		contentPane.add(lblNewLabel_1);
		btnNewButton.setBounds(93, 216, 158, 25);
		contentPane.add(btnNewButton);
		
//		///debut
			JPanel panel = new JPanel();
			panel.setBounds(851, 114, 137, 236);
			contentPane.add(panel);
			panel.setLayout(new GridLayout(1, 1));
			
			JLabel lab_imgg = new JLabel("");
			panel.add(lab_imgg);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(389, 114, 459, 236);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//clicked
				int ligne=table.getSelectedRow();//une fois cliqué sur une ligne dans la table"ligne" reçoit le num de la ligne
				//JOptionPane.showMessageDialog(null, ligne);
				 userold= table.getModel().getValueAt(ligne, 1).toString();
				//String sql= "select Materiel.nom,utilisateurs.username from Materiel,utilisateurs,Emprunt where Emprunt.id_materiel_a_empr=Materiel.id_materiel_a_empr AND Emprunt.id_user=utilisateurs.id_user AND nom='"+userold+"'";
				String sql="select * from Materiel where nom='"+userold+"'" ;
				 try {
					prepared =cnx.prepareStatement(sql);
					resultat= prepared.executeQuery();
					if(resultat.next())
					{  
						mat1.setText(resultat.getString("nom"));
						//user2.setText(resultat.getString("id_user"));
						
						//récupération de l'image a partir de la BD
						byte[] img= resultat.getBytes("photo");
						ImageIcon image= new ImageIcon(img);
						Image im=image.getImage();
						Image myImg=im.getScaledInstance(lab_imgg.getWidth(), lab_imgg.getHeight(), Image.SCALE_SMOOTH);
						ImageIcon imgg=new ImageIcon(myImg);
						lab_imgg.setIcon(imgg);
						
					}
					
					
		
				 } catch(SQLException e1) {
					 e1.printStackTrace();
				 }
				 
				
	
			
	}
		});
		scrollPane.setViewportView(table);
		
		 JLabel lab_imgg1;

		JButton actualiser = new JButton("");
		actualiser.setIcon(new ImageIcon("/home/zaki/eclipse-workspace/Gestion_materiel/images/reset.png"));
		actualiser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//actualiser
				UpdateTable();//appel a la fct UpdateTable();
			}
		});
		actualiser.setBounds(948, 70, 40, 29);
		contentPane.add(actualiser);
		
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//back
				Menu_administrateur obj= new Menu_administrateur();
				obj.setVisible(true);
				obj.setLocationRelativeTo(null);
				fermer();
			}
		});
		btnNewButton_1.setIcon(new ImageIcon("/home/zaki/eclipse-workspace/Gestion_materiel/images/backok.png"));
		btnNewButton_1.setBounds(12, 70, 46, 32);
		contentPane.add(btnNewButton_1);
		//appell a la fct remplirCombox()
		//remplirCombox();
		
		mat1 = new JTextField();
		mat1.setEditable(false);
		mat1.setFont(new Font("Dialog", Font.BOLD, 14));
		mat1.setForeground(Color.RED);
		mat1.setBounds(93, 175, 158, 29);
		contentPane.add(mat1);
		mat1.setColumns(10);
		
		JLabel lblRetourDeMatriel = new JLabel("Retour de Matériel:");
		lblRetourDeMatriel.setBounds(84, 106, 222, 37);
		contentPane.add(lblRetourDeMatriel);
		lblRetourDeMatriel.setFont(new Font("Khmer OS System", Font.BOLD, 18));
		
	

		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("/home/zaki/eclipse-workspace/Gestion_materiel/images/nouvel_emprunt.png"));
		lblNewLabel.setBounds(-12, 0, 1012, 612);
		contentPane.add(lblNewLabel);
		
		 JLabel lab_img = new JLabel("");
		 lab_img.setBounds(256, 131, 145, 122);
		 contentPane.add(lab_img);
	}
	
	public void UpdateTable() {
		String sql= "select Emprunt.id_emprunt as ID,Materiel.nom as MatérielEmprunté,Emprunt.date_prendre as DateEmprunt, Emprunt.date_rendre as DateRetour, Emprunt.duree_reserv as DuréeEmprunt,Materiel.photo as Image,utilisateurs.username as user from utilisateurs,Materiel, Emprunt where Emprunt.id_materiel_a_empr=Materiel.id_materiel_a_empr AND Emprunt.id_user=utilisateurs.id_user";
		try {
			prepared= cnx.prepareStatement(sql);
			resultat=prepared.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(resultat));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
