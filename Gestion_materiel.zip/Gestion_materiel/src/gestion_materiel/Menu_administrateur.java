package gestion_materiel;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Menu_administrateur extends JFrame {

	private JPanel contentPane;
	//méthode pour fermer une fenêtre
	void fermer() {
		dispose();
	}


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Menu_administrateur frame = new Menu_administrateur();
					frame.setVisible(true);
					//fixer la fenetre à la mm taille d'autres fenetres
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Menu_administrateur() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1000, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				emprunt_materiel empr1= new emprunt_materiel();
				empr1.setVisible(true);// redirection vers la page emprunt materiel
				empr1.setLocationRelativeTo(null);///pr que la fenetre reste au milieu
				fermer();

			}
		});
		btnNewButton.setIcon(new ImageIcon("/home/zaki/eclipse-workspace/Gestion_materiel/images/ok/matttt.png"));
		btnNewButton.setBounds(64, 97, 222, 251);
		contentPane.add(btnNewButton);
		
		JButton button = new JButton("");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Retour_materiel empr2= new Retour_materiel ();
				empr2.setVisible(true);// redirection vers la page emprunt materiel
				empr2.setLocationRelativeTo(null);///pr que la fenetre reste au milieu
				fermer();
			}
		});
		button.setIcon(new ImageIcon("/home/zaki/eclipse-workspace/Gestion_materiel/images/ok/r.png"));
		button.setBounds(678, 97, 237, 255);
		contentPane.add(button);
		
		JLabel lblNewLabel_1 = new JLabel("Emprunt de Matériel");
		lblNewLabel_1.setForeground(new Color(25, 25, 112));
		lblNewLabel_1.setFont(new Font("URW Bookman L", Font.BOLD, 20));
		lblNewLabel_1.setBounds(64, 360, 237, 21);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblRetourDeMatriel = new JLabel("Retour de Matériel");
		lblRetourDeMatriel.setForeground(new Color(0, 0, 128));
		lblRetourDeMatriel.setFont(new Font("URW Bookman L", Font.BOLD, 20));
		lblRetourDeMatriel.setBounds(699, 360, 237, 21);
		contentPane.add(lblRetourDeMatriel);
		
		JButton button_1 = new JButton("");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ComptesUsers comp= new ComptesUsers();
				comp.setVisible(true);// redirection vers la page emprunt materiel
				comp.setLocationRelativeTo(null);///pr que la fenetre reste au milieu
				fermer();
			}
		});
		button_1.setIcon(new ImageIcon("/home/zaki/eclipse-workspace/Gestion_materiel/images/ok/usersss.png"));
		button_1.setBounds(364, 93, 224, 255);
		contentPane.add(button_1);
		
		JLabel lblConsultationDesComptes = new JLabel(" Comptes Utilisateurs");
		lblConsultationDesComptes.setForeground(new Color(0, 0, 128));
		lblConsultationDesComptes.setFont(new Font("URW Bookman L", Font.BOLD, 20));
		lblConsultationDesComptes.setBounds(364, 360, 422, 21);
		contentPane.add(lblConsultationDesComptes);

		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("/home/zaki/eclipse-workspace/Gestion_materiel/images/logo_principal.png"));
		lblNewLabel.setBounds(0, 0, 1000, 612);
		contentPane.add(lblNewLabel);
	}
}
