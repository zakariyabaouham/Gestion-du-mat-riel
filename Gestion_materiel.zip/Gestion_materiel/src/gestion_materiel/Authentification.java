package gestion_materiel;

import java.awt.EventQueue;
import java.awt.Toolkit;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JPanel;	
import javax.swing.JTextField;

import zakiz.connexionMysql;

import javax.swing.JButton;
import java.awt.Font;	
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.Color;
import java.awt.SystemColor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;	

public class Authentification extends JFrame{

	private JFrame frame;
	private JTextField UsernameField;
	private JPasswordField passwordField;
	//méthode pour fermer une fenêtre
	void fermer() {
		frame.dispose();//pk dans ce cas on a travaillé avec app window 
	}

	
	
	//Creation des 3 objets de type Connection
	Connection cnx=null; // poyr établir la BD
	PreparedStatement prepared= null; //pr exécuter une requête	 
	ResultSet resultat= null; //récupération des infos de BD
	
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Authentification window = new Authentification();
					window.frame.setVisible(true);
					//fixer la fenetre à la mm taille d'autres fenetres
					window.frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Authentification() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 1000, 500);// les dimesions de la fenetre
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		//établissement de la connexion DB
		cnx= connexionMysql.ConnexionDB();
		//end etablissement de la cnx
		
		JLabel lblNewLabel_1 = new JLabel("Username:");
		lblNewLabel_1.setFont(new Font("Khmer OS System", Font.BOLD, 18));
		lblNewLabel_1.setBounds(298, 149, 121, 39);
		frame.getContentPane().add(lblNewLabel_1);
		
		UsernameField = new JTextField();
		UsernameField.setBounds(420, 155, 156, 25);
		frame.getContentPane().add(UsernameField);
		UsernameField.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Password:");
		lblNewLabel_2.setFont(new Font("Khmer OS System", Font.BOLD, 18));
		lblNewLabel_2.setBounds(308, 200, 121, 34);
		frame.getContentPane().add(lblNewLabel_2);
		
		JButton btnSeConnecter = new JButton("Se connecter");
		btnSeConnecter.setFont(new Font("Khmer OS System", Font.BOLD, 14));
		btnSeConnecter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				//Récupération des données saisies par user
				String username= UsernameField.getText().toString();
				String password= passwordField.getText().toString();
				
				String sql= "select username, password from utilisateurs"; 
				try {
					prepared= cnx.prepareStatement(sql);//préparer la requête
					resultat=prepared.executeQuery();//éxécution de la requête
					//pr tester chaque ligne dans la table DB
				int i=0;
				if(username.equals("") || password.equals("")) {
					JOptionPane.showMessageDialog(null, "Remplissez les champs sont vides 😜");
				}
				else {
					while(resultat.next()) {
						String username1= resultat.getString("username");
						String password1= resultat.getString("password");
						if(username1.equals(username) && password1.equals(password))
						{
							JOptionPane.showMessageDialog(null, "connexion réussite 😜");
							i=1;
							Menu_administrateur empr= new Menu_administrateur();
							empr.setVisible(true);// redirection vers la page menu
							empr.setLocationRelativeTo(null);///pr que la fenetre reste au milieu
							fermer();
						
						}
						
						
						
					
					}
					
				if(i==0) {
					JOptionPane.showMessageDialog(null, "connexion échouée : Infos incorrectes 😜");
				}
				}
			
				} catch (SQLException e1) {
				
					e1.printStackTrace();
				}
			}
		});
		btnSeConnecter.setBounds(420, 252, 156, 25);
		frame.getContentPane().add(btnSeConnecter);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(420, 205, 156, 25);
		frame.getContentPane().add(passwordField);
		
		JLabel lblNewLabel_3 = new JLabel("Forgot Password");
		lblNewLabel_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				IndicationPass obj= new IndicationPass();
				obj.setVisible(true);
				obj.setLocationRelativeTo(null);
				
			}
		});
		lblNewLabel_3.setForeground(Color.RED);
		lblNewLabel_3.setFont(new Font("Khmer OS System", Font.BOLD, 11));
		lblNewLabel_3.setBounds(474, 229, 130, 20);
		frame.getContentPane().add(lblNewLabel_3);
		
	
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("/home/zaki/eclipse-workspace/Gestion_materiel/images/logo_principal.png"));
		lblNewLabel.setBounds(0, 0, 1047, 610);
		frame.getContentPane().add(lblNewLabel);
	}
}
