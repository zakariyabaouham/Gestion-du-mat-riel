package gestion_materiel;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Toolkit;
import javax.swing.ImageIcon;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.Color;

public class IndicationPass extends JFrame {

	private JPanel contentPane;
	//Creation des 3 objets de type Connection
	Connection cnx=null; // poyr établir la BD
	PreparedStatement prepared= null; //pr exécuter une requête	 
	ResultSet resultat= null; //récupération des infos de BD
	private final JLabel lblNewLabel_1 = new JLabel("");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					IndicationPass frame = new IndicationPass();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public IndicationPass() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 577, 200);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		//établissement de la connexion DB
				cnx= connexionMysql.ConnexionDB();
				//end etablissement de la cnx
		
		JTextArea use = new JTextArea();
		use.setForeground(Color.RED);
		use.setFont(new Font("Dialog", Font.BOLD, 12));
		use.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				String username=use.getText().toString();
				String sql= "select password from utilisateurs where username= ?";
				try {
					prepared= cnx.prepareStatement(sql);
					prepared.setString(1,username); // le 1er argument passe
					resultat= prepared.executeQuery(); 
					if(resultat.next())
					{
						String pass= resultat.getString("password");
						String pass1= pass.substring(0,3);
						use.setText("Les 3 premières lettres du Mot de Passe sont : "+pass1+"*****");// pour remplir cette case
					}
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			
			}
		});
		use.setBounds(67, 60, 403, 22);
		contentPane.add(use);
		
		JLabel lblNewLabel = new JLabel("Username :");
		lblNewLabel.setFont(new Font("FreeSans", Font.BOLD, 16));
		lblNewLabel.setBounds(223, 27, 104, 31);
		contentPane.add(lblNewLabel);
		lblNewLabel_1.setIcon(new ImageIcon("/home/zaki/eclipse-workspace/Gestion_materiel/images/imageProfil.png"));
		lblNewLabel_1.setBounds(0, -21, 577, 201);
		contentPane.add(lblNewLabel_1);
		
	}
}
