package gestion_materiel;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import net.proteanit.sql.DbUtils;

import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class Affectation_materiel extends JFrame {

	private JPanel contentPane;
	private JTextField username;
	String userold= null;
	private String s;

	//Creation des 3 objets de type Connection
		Connection cnx=null; // poyr établir la BD
		PreparedStatement prepared= null; //pr exécuter une requête	 
		ResultSet resultat= null; //récupération des infos de BD
		private JTable table;
		//méthode pour fermer une fenêtre
		void fermer() {
			dispose();
		}
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Affectation_materiel frame = new Affectation_materiel();
					frame.setVisible(true);
					//fixer la fenetre à la mm taille d'autres fenetres
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Affectation_materiel() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1000, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		//établissement de la connexion DB
		cnx= connexionMysql.ConnexionDB();
		
		JLabel lblKkk = new JLabel("Nom du matériel:");
		lblKkk.setBounds(22, 101, 153, 32);
		contentPane.add(lblKkk);
		
		username = new JTextField();
		username.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
			/*	String sql = "select nom,prenom, email,password from utilisateurs where username=?";
				try {
					prepared= cnx.prepareStatement(sql);
					prepared.setString(1, username.getText().toString());
					resultat= prepared.executeQuery();
					if(resultat.next()) {
						String pass= resultat.getString("password");
						passwor.setText(pass);

						
					}
				
					} 
				catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} */
			}
		});
		username.setBounds(153, 102, 145, 32);
		contentPane.add(username);
		username.setColumns(10);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.setIcon(new ImageIcon("/home/zaki/eclipse-workspace/Gestion_materiel/images/ok/add.png"));
		btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					String us=username.getText().toString();
			String sql="insert into Materiel(nom, photo) values (?, ?)"; // réquete insert
		
			try {
				InputStream imgg=new FileInputStream(new File(s));
				
			
				if(!us.equals("")) {
					prepared = cnx.prepareStatement(sql);// préparation de la requete
					prepared.setString(1, us);
					prepared.setBlob(2, imgg);
					prepared.execute();//éxécution de la requete
					JOptionPane.showMessageDialog(null, "Matériel ajouté avec succès. 😜");
					username.setText("");
					
					UpdateTable();//appel a la fct UpdateTable();
					
				}
				else {
					JOptionPane.showMessageDialog(null, "Remplissez les champs vides !! 😜");
				}
				
			
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			}
		});
		//	///debut
		JPanel panel = new JPanel();
		panel.setBounds(153, 142, 145, 122);
		contentPane.add(panel);
		panel.setLayout(new GridLayout(1, 1));
		
		 JLabel lab_img = new JLabel("");
		panel.add(lab_img);
		
		JButton parcourir = new JButton("Parcourir");
		parcourir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				JFileChooser fileChooser= new JFileChooser();
				fileChooser.setCurrentDirectory(new File("/home/zaki/eclipse-workspace/Gestion_materiel/images"));
				FileNameExtensionFilter filter= new FileNameExtensionFilter("IMAGE", "jpg", "png", "gif");
				fileChooser.addChoosableFileFilter(filter);
				int result= fileChooser.showSaveDialog(null);
				
				if(result== JFileChooser.APPROVE_OPTION) {
					File selectedfile=fileChooser.getSelectedFile();
					String path = selectedfile.getAbsolutePath();
					ImageIcon myImage= new ImageIcon(path);
					Image img= myImage.getImage();
					Image newImage= img.getScaledInstance(lab_img.getWidth(), lab_img.getHeight(), Image.SCALE_SMOOTH);
				
					ImageIcon finalImg= new ImageIcon(newImage);
					lab_img.setIcon(finalImg);
					s= path;
					}
				else {
					if(result== JFileChooser.CANCEL_OPTION)
						JOptionPane.showMessageDialog(null, "T'as rien choisi !!");
				}
				
			} 
			
		});
		parcourir.setBounds(153, 270, 145, 25);
		contentPane.add(parcourir);
		//end
		btnNewButton.setBounds(95, 307, 80, 78);
		contentPane.add(btnNewButton);
		
		JButton Supprimer = new JButton("");
		Supprimer.setIcon(new ImageIcon("/home/zaki/eclipse-workspace/Gestion_materiel/images/ok/remove.png"));
		Supprimer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String sql="delete from Materiel where nom=?";
				try {
					prepared= cnx.prepareStatement(sql);
					prepared.setString(1, username.getText().toString());
					prepared.execute();
					JOptionPane.showMessageDialog(null, "Matériel supprimé avec succès. 😜");
					username.setText("");

					UpdateTable();//appel a la fct UpdateTable();
				
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		Supprimer.setBounds(187, 307, 87, 78);
		contentPane.add(Supprimer);
		
		JButton modifier = new JButton("");
		modifier.setIcon(new ImageIcon("/home/zaki/eclipse-workspace/Gestion_materiel/images/ok/update.png"));
		modifier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//modifier
			     String userr= username.getText().toString();
					String sql="update Materiel set nom=?,photo=? where nom='"+userold+"'";
					try {
						InputStream in=new FileInputStream(new File(s));
						prepared=cnx.prepareStatement(sql);
						
						prepared.setString(1, userr);
						prepared.setBlob(2, in);
					    
						String us=username.getText();
						if(!us.equals("")) 
						{
						prepared.execute();		
						JOptionPane.showMessageDialog(null, "Matériel modifié avec succès. 😜");
						UpdateTable();//appel a la fct UpdateTable();
						}
						else {
							JOptionPane.showMessageDialog(null, "Remplissez les champs vides !! 😜");
						}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				
		
				
			}
				
				
				
	/*			int ligne=table.getSelectedRow();
				if(ligne == -1)
				{
					JOptionPane.showMessageDialog(null, "Séléctionnez un matériel !! 😜");
				}
				else {
					   String user= table.getModel().getValueAt(ligne, 0).toString();
					   
					   String sql="update Materiel set nom=?, photo=? where username='"+userold+"'"; 
					   
				
				try {
					InputStream in=new FileInputStream(new File(s));
					prepared=cnx.prepareStatement(sql);
					prepared.setString(1, username.getText().toString());
					prepared.setBlob(2, in);
				   
					prepared.execute();		
					JOptionPane.showMessageDialog(null, "Matériel modifié avec succès. 😜");
					UpdateTable();//appel a la fct UpdateTable();
					username.setText("");
					
					
				}
					
				
				catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				catch (FileNotFoundException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				
		
				
			} */
			
		});
		modifier.setBounds(286, 307, 80, 78);
		contentPane.add(modifier);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(490, 102, 498, 274);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//clicked
				int ligne=table.getSelectedRow();//une fois cliqué sur une ligne dans la table"ligne" reçoit le num de la ligne
				//JOptionPane.showMessageDialog(null, ligne);
				 userold= table.getModel().getValueAt(ligne, 0).toString();
				 String sql="select * from Materiel where nom='"+userold+"'";
				 try {
					prepared =cnx.prepareStatement(sql);
					resultat= prepared.executeQuery();
					if(resultat.next())
					{
						username.setText(resultat.getString("nom"));
						
						//récupération de l'image a partir de la BD
						byte[] img= resultat.getBytes("photo");
						ImageIcon image= new ImageIcon(img);
						Image im=image.getImage();
						Image myImg=im.getScaledInstance(lab_img.getWidth(), lab_img.getHeight(), Image.SCALE_SMOOTH);
						ImageIcon imgg=new ImageIcon(myImg);
						lab_img.setIcon(imgg);
						
					}
					
					
		
				 } catch(SQLException e1) {
					 e1.printStackTrace();
				 }
				 
	
			}
		});
		scrollPane.setViewportView(table);
		
		JButton actualiser = new JButton("");
		actualiser.setIcon(new ImageIcon("/home/zaki/eclipse-workspace/Gestion_materiel/images/reset.png"));
		actualiser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//actualiser
				UpdateTable();//appel a la fct UpdateTable();
			}
		});
		actualiser.setBounds(948, 70, 40, 29);
		contentPane.add(actualiser);
		
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//back
				emprunt_materiel obj= new emprunt_materiel();
				obj.setVisible(true);
				obj.setLocationRelativeTo(null);
				fermer();
			}
		});
		btnNewButton_1.setIcon(new ImageIcon("/home/zaki/eclipse-workspace/Gestion_materiel/images/backok.png"));
		btnNewButton_1.setBounds(12, 70, 46, 32);
		contentPane.add(btnNewButton_1);
		
		JLabel lblListeMatriels = new JLabel("Liste Matériels:");
		lblListeMatriels.setFont(new Font("Khmer OS System", Font.BOLD, 18));
		lblListeMatriels.setBounds(490, 75, 145, 26);
		contentPane.add(lblListeMatriels);
		
		JLabel lblNouvelMatriel = new JLabel("Nouvel Matériel:");
		lblNouvelMatriel.setFont(new Font("Khmer OS System", Font.BOLD, 18));
		lblNouvelMatriel.setBounds(153, 73, 145, 26);
		contentPane.add(lblNouvelMatriel);

		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("/home/zaki/eclipse-workspace/Gestion_materiel/images/logo2.png"));
		lblNewLabel.setBounds(-12, 0, 1012, 612);
		contentPane.add(lblNewLabel);
	}
	public void UpdateTable() {
		String sql= "select nom, photo from Materiel";
		try {
			prepared= cnx.prepareStatement(sql);
			resultat=prepared.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(resultat));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}

		
		/*JPanel panel = new JPanel();
		panel.setBounds(153, 142, 145, 122);
		contentPane.add(panel);
		panel.setLayout(new GridLayout(1, 1));
		
		 JLabel lab_img = new JLabel("");
		panel.add(lab_img);
		
		JButton parcourir = new JButton("Parcourir");
		parcourir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				///debut
				JFileChooser fileChooser= new JFileChooser();
				fileChooser.setCurrentDirectory(new File("/home/zaki/eclipse-workspace/Gestion_materiel/images"));
				FileNameExtensionFilter filter= new FileNameExtensionFilter("IMAGE", "jpg", "png", "gif");
				fileChooser.addChoosableFileFilter(filter);
				int result= fileChooser.showSaveDialog(null);
				
				if(result== JFileChooser.APPROVE_OPTION) {
					File selectedfile=fileChooser.getSelectedFile();
					String path = selectedfile.getAbsolutePath();
					ImageIcon myImage= new ImageIcon(path);
					Image img= myImage.getImage();
					Image newImage= img.getScaledInstance(lab_img.getWidth(), lab_img.getHeight(), Image.SCALE_SMOOTH);
				
					ImageIcon finalImg= new ImageIcon(newImage);
					lab_img.setIcon(finalImg);
					s= path;
					}
				else {
					if(result== JFileChooser.CANCEL_OPTION)
						JOptionPane.showMessageDialog(null, "T'as rien choisi !!");
				}
				
			} 
			
		});
		parcourir.setBounds(153, 270, 145, 25);
		contentPane.add(parcourir);*/
		
		