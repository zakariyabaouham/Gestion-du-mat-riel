package gestion_materiel;
import javax.swing.*;
import java.sql.*;

public class connexionMysql {
	Connection conn=null;//intialiser conn de type Connection (classe prédifinie) par null pk on va la stocker après
	public static Connection ConnexionDB() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn= DriverManager.getConnection("jdbc:mysql://localhost/Gestion_materiel","root","");
			//stocker l'objet conn par les infos de DB
			return conn;
		}catch(Exception e)
		{
			JOptionPane.showMessageDialog(null, e);
			return null;
		}
		
	}

}
