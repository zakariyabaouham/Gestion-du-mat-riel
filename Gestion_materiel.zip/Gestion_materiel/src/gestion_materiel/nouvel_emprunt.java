package gestion_materiel;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import net.proteanit.sql.DbUtils;

import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;

import javax.swing.JComboBox;
import javax.swing.JFileChooser;

import com.toedter.calendar.JDateChooser;
import java.awt.Color;

public class nouvel_emprunt extends JFrame {

	private JPanel contentPane;
	String userold= null;
	private String s;
	JDateChooser date_empr_box;
	JComboBox duree_empr_box;
	JDateChooser date_r_box ;
	
	JComboBox mat_box;// variable globale
	JComboBox id_usr_box;

	//Creation des 3 objets de type Connection
		Connection cnx=null; // poyr établir la BD
		PreparedStatement prepared= null; //pr exécuter une requête	 
		ResultSet resultat= null; //récupération des infos de BD
		private JTable table;
		private JTextField lab_userr;
		private JTextField id_img;
		//méthode pour fermer une fenêtre
		void fermer() {
			dispose();
		}
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					 nouvel_emprunt frame = new  nouvel_emprunt();
					frame.setVisible(true);
					//fixer la fenetre à la mm taille d'autres fenetres
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public  nouvel_emprunt() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1000, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		//établissement de la connexion DB
		cnx= connexionMysql.ConnexionDB();
	
		
		JLabel mat = new JLabel("Séléctionnez le matériel concerné:");
		mat.setBounds(45, 94, 274, 32);
		contentPane.add(mat);
		
		JLabel date_r = new JLabel("Date de  retour:");
		date_r.setBounds(45, 342, 137, 29);
		contentPane.add(date_r);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.setIcon(new ImageIcon("/home/zaki/eclipse-workspace/Gestion_materiel/images/ok/add.png"));
		btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				//String mat_box id_usr_box
			//		date_empr_box date_r_box duree_empr_box
					String mat=id_img.getText().toString();
					String lab_user=lab_userr.getText().toString();
					String duree_empr= duree_empr_box.getSelectedItem().toString();
					//récupérer la date
					String date_empr=((JTextField) date_empr_box.getDateEditor().getUiComponent()).getText();
					// date_empr_box.setDateFormatString("yyyy-MM-dd");//format date
					String date_r= ((JTextField) date_r_box.getDateEditor().getUiComponent()).getText();
					String sql= "insert into Emprunt (id_user,id_materiel_a_empr,date_prendre,date_rendre,duree_reserv) values (?,?,?,?,?)";
					try {
						if(id_img.getText().equals("") || lab_userr.getText().equals("") || duree_empr_box.getSelectedItem().equals("")) {
							JOptionPane.showMessageDialog(null, "Complétez les informations. 😜");
						}
						else{
						prepared=cnx.prepareStatement(sql);
						prepared.setString(1, mat);
						prepared.setString(2, lab_user);
						prepared.setString(3, date_empr);
						prepared.setString(4, date_r);
						prepared.setString(5, duree_empr);
						
						prepared.execute();						
						id_img.setText("");
						lab_userr.setText("");
						duree_empr_box.setSelectedItem("");
						date_empr_box.setDateFormatString("");
						date_r_box.setDateFormatString("");
						JOptionPane.showMessageDialog(null, "L'emprunt Matériel a bien été enrigistré dans la base. 😜");
						UpdateTable();
						
						
					} 
					}catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				
					//String sql="insert into utilisateurs(username,nom,prenom,email,password) values (?, ?, ?, ?, ?)"; // réquete insert
			
			}
		});
		btnNewButton.setBounds(244, 327, 75, 78);
		contentPane.add(btnNewButton);
		
		JLabel lblMatrielsEmprunts = new JLabel("Matériels empruntés:");
		lblMatrielsEmprunts.setFont(new Font("Khmer OS System", Font.BOLD, 18));
		lblMatrielsEmprunts.setBounds(389, 76, 304, 50);
		contentPane.add(lblMatrielsEmprunts);
		
		JLabel date_empr = new JLabel("Date de l'emprunt:");
		date_empr.setBounds(45, 290, 158, 32);
		contentPane.add(date_empr);
		
		JLabel id_usr = new JLabel("Utilisateur:");
		id_usr.setBounds(45, 148, 102, 15);
		contentPane.add(id_usr);
		
//		///debut
			JPanel panel = new JPanel();
			panel.setBounds(851, 114, 137, 236);
			contentPane.add(panel);
			panel.setLayout(new GridLayout(1, 1));
			
			JLabel lab_imgg = new JLabel("");
			panel.add(lab_imgg);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(389, 114, 459, 236);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//clicked
				int ligne=table.getSelectedRow();//une fois cliqué sur une ligne dans la table"ligne" reçoit le num de la ligne
				//JOptionPane.showMessageDialog(null, ligne);
				 userold= table.getModel().getValueAt(ligne, 1).toString();
				 String sql="select * from Materiel where nom='"+userold+"'";
				 try {
					prepared =cnx.prepareStatement(sql);
					resultat= prepared.executeQuery();
					if(resultat.next())
					{
						
						//récupération de l'image a partir de la BD
						byte[] img= resultat.getBytes("photo");
						ImageIcon image= new ImageIcon(img);
						Image im=image.getImage();
						Image myImg=im.getScaledInstance(lab_imgg.getWidth(), lab_imgg.getHeight(), Image.SCALE_SMOOTH);
						ImageIcon imgg=new ImageIcon(myImg);
						lab_imgg.setIcon(imgg);
						
					}
					
					
		
				 } catch(SQLException e1) {
					 e1.printStackTrace();
				 }
				 
				
	
			
	}
		});
		scrollPane.setViewportView(table);
	
		JPanel panel1 = new JPanel();
		panel1.setBounds(211, 131, 158, 184);
		contentPane.add(panel1);
		panel1.setLayout(new GridLayout(1, 1));
		
		JLabel lab1 = new JLabel("");
		panel1.add(lab1);
		
		 JLabel lab_imgg1;

		JButton actualiser = new JButton("");
		actualiser.setIcon(new ImageIcon("/home/zaki/eclipse-workspace/Gestion_materiel/images/reset.png"));
		actualiser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//actualiser
				UpdateTable();//appel a la fct UpdateTable();
			}
		});
		actualiser.setBounds(948, 70, 40, 29);
		contentPane.add(actualiser);
		
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//back
				emprunt_materiel obj= new emprunt_materiel();
				obj.setVisible(true);
				obj.setLocationRelativeTo(null);
				fermer();
			}
		});
		btnNewButton_1.setIcon(new ImageIcon("/home/zaki/eclipse-workspace/Gestion_materiel/images/backok.png"));
		btnNewButton_1.setBounds(12, 70, 46, 32);
		contentPane.add(btnNewButton_1);
		
		mat_box = new JComboBox();
		mat_box.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				
			}
		});
		mat_box.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				
				 
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				
			}
			@Override
			public void mouseReleased(MouseEvent e) {
				//
				//clicked
			//une fois cliqué sur une ligne dans la table"ligne" reçoit le num de la ligne
				//JOptionPane.showMessageDialog(null, ligne);
				 userold= mat_box.getSelectedItem().toString();
				 String sql="select * from Materiel where nom='"+userold+"'";
				 try {
					prepared =cnx.prepareStatement(sql);
					resultat= prepared.executeQuery();
					if(resultat.next())
					{
						id_img.setText(resultat.getString("id_materiel_a_empr"));
						//récupération de l'image a partir de la BD
						byte[] img= resultat.getBytes("photo");
						ImageIcon image= new ImageIcon(img);
						Image im=image.getImage();
						Image myImg=im.getScaledInstance(lab1.getWidth(), lab1.getHeight(), Image.SCALE_SMOOTH);
						ImageIcon imgg=new ImageIcon(myImg);
						lab1.setIcon(imgg);
						
					}
					
					
		
				 } catch(SQLException e1) {
					 e1.printStackTrace();
				 }
			}
		});
		mat_box.setBounds(45, 119, 158, 28);
		contentPane.add(mat_box);
		//appell a la fct remplirCombox()
		remplirCombox();
		
		JLabel duree = new JLabel("Durée de l'emprunt:");
		duree.setBounds(45, 396, 181, 21);
		contentPane.add(duree);
		
		JLabel lab_user = new JLabel(" ID User:");
		lab_user.setBounds(45, 241, 102, 15);
		contentPane.add(lab_user);
		
		lab_userr = new JTextField();
		lab_userr.setEditable(false);
		lab_userr.setFont(new Font("Dialog", Font.BOLD, 14));
		lab_userr.setForeground(Color.RED);
		lab_userr.setBounds(45, 261, 158, 29);
		contentPane.add(lab_userr);
		lab_userr.setColumns(10);
		
		id_usr_box = new JComboBox();
		id_usr_box.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				//
				//clicked
			//une fois cliqué sur une ligne dans la table"ligne" reçoit le num de la ligne
				//JOptionPane.showMessageDialog(null, ligne);
				 userold= id_usr_box.getSelectedItem().toString();
				 String sql="select * from utilisateurs where username='"+userold+"'";
				 try {
					prepared =cnx.prepareStatement(sql);
					resultat= prepared.executeQuery();
					if(resultat.next())
					{
						lab_userr.setText(resultat.getString("id_user"));
						
					
						
					}
					
					
		
				 } catch(SQLException e1) {
					 e1.printStackTrace();
				 }
				
				
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				
				
			}
			@Override
			public void mousePressed(MouseEvent e) {
		
			}
		});
		
		JLabel lblNouvelEmprunt = new JLabel("Nouvel emprunt:");
		lblNouvelEmprunt.setFont(new Font("Khmer OS System", Font.BOLD, 18));
		lblNouvelEmprunt.setBounds(101, 70, 215, 32);
		contentPane.add(lblNouvelEmprunt);
		id_usr_box.setBounds(45, 165, 158, 28);
		contentPane.add(id_usr_box);
		//appell a la fct remplirComboxUser()
		remplirComboxUser();
		
		Object[] elements = new Object[]{"un jour", "un jour à 15 jours", "15 jours à un mois", "un mois à 2 mois", "2 mois à 3 mois","2 mois à 6 mois"};
		duree_empr_box = new JComboBox(elements);
		duree_empr_box.setBounds(45, 416, 158, 28);
		contentPane.add(duree_empr_box);
		
		date_empr_box = new JDateChooser();
		date_empr_box.setBounds(45, 314, 158, 32);
		contentPane.add(date_empr_box);
	    date_empr_box.setDateFormatString("yyyy-MM-dd");//format date
		
		id_img = new JTextField();
		id_img.setForeground(Color.RED);
		id_img.setFont(new Font("Dialog", Font.BOLD, 14));
		id_img.setEditable(false);
		id_img.setColumns(10);
		id_img.setBounds(45, 212, 158, 28);
		contentPane.add(id_img);
		
		JLabel lab_imggg = new JLabel(" ID Matériel:");
		lab_imggg.setBounds(45, 195, 102, 15);
		contentPane.add(lab_imggg);
		
		
		date_r_box = new JDateChooser();
		date_r_box.setBounds(45, 366, 158, 32);
		contentPane.add(date_r_box);
		 date_r_box.setDateFormatString("yyyy-MM-dd");//format date
		
	

		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("/home/zaki/eclipse-workspace/Gestion_materiel/images/nouvel_emprunt.png"));
		lblNewLabel.setBounds(-12, 0, 1012, 612);
		contentPane.add(lblNewLabel);
		
		 JLabel lab_img = new JLabel("");
		 lab_img.setBounds(256, 131, 145, 122);
		 contentPane.add(lab_img);
	}
	
	public void UpdateTable() {
		String sql= "select Materiel.id_materiel_a_empr as ID, Materiel.nom as MatérielEmprunté,Emprunt.date_prendre as DateEmprunt, Emprunt.date_rendre as DateRetour, Emprunt.duree_reserv as DuréeEmprunt,Materiel.photo as Image,utilisateurs.username as user from utilisateurs,Materiel, Emprunt where Emprunt.id_materiel_a_empr=Materiel.id_materiel_a_empr AND Emprunt.id_user=utilisateurs.id_user";
		try {
			prepared= cnx.prepareStatement(sql);
			resultat=prepared.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(resultat));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	// remplirCombox
	public void remplirCombox() {
		String sql="select nom from Materiel where id_materiel_a_empr not in (select Emprunt.id_materiel_a_empr from Materiel, Emprunt where Materiel.id_materiel_a_empr=Emprunt.id_materiel_a_empr)";
		try {
			prepared = cnx.prepareStatement(sql);
			resultat= prepared.executeQuery();
			while(resultat.next()) {
				String nom=resultat.getString("Materiel.nom").toString();
				mat_box.addItem(nom);
				
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	//remplircomboxUser
	public void remplirComboxUser() {
		String sql="select username from utilisateurs where id_user not in (select Emprunt.id_user from Emprunt, utilisateurs where utilisateurs.id_user=Emprunt.id_user)";
		try {
			prepared = cnx.prepareStatement(sql);
			resultat= prepared.executeQuery();
			while(resultat.next()) {
				String no=resultat.getString("username").toString();
				id_usr_box.addItem(no);
				
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
