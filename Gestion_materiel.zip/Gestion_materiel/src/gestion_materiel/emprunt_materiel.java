package gestion_materiel;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class emprunt_materiel extends JFrame {

	private JPanel contentPane;
	private JTextField passwor;
	private JTextField username;
	String userold= null;

	//Creation des 3 objets de type Connection
		Connection cnx=null; // poyr établir la BD
		PreparedStatement prepared= null; //pr exécuter une requête	 
		ResultSet resultat= null; //récupération des infos de BD
		private JTextField nom;
		private JTextField prenom;
		private JTextField email;
		private JTable table;
		//méthode pour fermer une fenêtre
		void fermer() {
			dispose();
		}
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					emprunt_materiel frame = new emprunt_materiel();
					frame.setVisible(true);
					//fixer la fenetre à la mm taille d'autres fenetres
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public emprunt_materiel() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1000, 500);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnOuvrir = new JMenu("Ouvrir une page");
		menuBar.add(mnOuvrir);
		
		JMenuItem mntmNouvelEmprunt = new JMenuItem("Nouvel Emprunt");
		mntmNouvelEmprunt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				nouvel_emprunt empr3= new nouvel_emprunt();
				empr3.setVisible(true);// redirection vers la page emprunt materiel
				empr3.setLocationRelativeTo(null);///pr que la fenetre reste au milieu
				fermer(); 
			}
		});
		mnOuvrir.add(mntmNouvelEmprunt);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Nouvel Matériel");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 Affectation_materiel empr4= new Affectation_materiel();
				empr4.setVisible(true);// redirection vers la page emprunt materiel
				empr4.setLocationRelativeTo(null);///pr que la fenetre reste au milieu
				fermer(); 
			}
		});
		mnOuvrir.add(mntmNewMenuItem);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		//établissement de la connexion DB
		cnx= connexionMysql.ConnexionDB();
		//end etablissement de la cnx
		
		
		passwor = new JTextField();
		passwor.setBounds(190, 257, 158, 32);
		contentPane.add(passwor);
		passwor.setColumns(10);
		
		JLabel lblKkk = new JLabel("Username:");
		lblKkk.setBounds(102, 112, 88, 32);
		contentPane.add(lblKkk);
		
		JLabel password = new JLabel("Password:");
		password.setBounds(102, 256, 88, 32);
		contentPane.add(password);
		
		username = new JTextField();
		username.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
			/*	String sql = "select nom,prenom, email,password from utilisateurs where username=?";
				try {
					prepared= cnx.prepareStatement(sql);
					prepared.setString(1, username.getText().toString());
					resultat= prepared.executeQuery();
					if(resultat.next()) {
						String pass= resultat.getString("password");
						passwor.setText(pass);

						
					}
				
					} 
				catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} */
			}
		});
		username.setBounds(190, 113, 158, 32);
		contentPane.add(username);
		username.setColumns(10);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.setIcon(new ImageIcon("/home/zaki/eclipse-workspace/Gestion_materiel/images/add.png"));
		btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
			
			String sql="insert into utilisateurs(username,nom,prenom,email,password) values (?, ?, ?, ?, ?)"; // réquete insert
			try {
				prepared = cnx.prepareStatement(sql);// préparation de la requete
				prepared.setString(1, username.getText().toString());
				prepared.setString(2, nom.getText().toString());
				prepared.setString(3, prenom.getText().toString());
				prepared.setString(4, email.getText().toString());
				prepared.setString(5, passwor.getText().toString());
				String us=username.getText();
				String pa=passwor.getText();
				String noo=nom.getText();
				String pr=prenom.getText();
				String mai=email.getText();
				if(!us.equals("") && !pa.equals("") && !noo.equals("") && !pr.equals("") && !mai.equals("")) {
					
					prepared.execute();//éxécution de la requete
					JOptionPane.showMessageDialog(null, "Utilisateur ajouté avec succès. 😜");
					UpdateTable();//appel a la fct UpdateTable();
					
				}
				else {
					JOptionPane.showMessageDialog(null, "Remplissez les champs vides !! 😜");
				}
				
			
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			}
		});
		btnNewButton.setBounds(190, 296, 46, 44);
		contentPane.add(btnNewButton);
		
		JLabel lblPrnom = new JLabel("Prénom:");
		lblPrnom.setBounds(120, 192, 70, 15);
		contentPane.add(lblPrnom);
		
		JLabel lblNom = new JLabel("Nom:");
		lblNom.setBounds(142, 156, 70, 15);
		contentPane.add(lblNom);
		
		JLabel lblPassword = new JLabel("Email:");
		lblPassword.setBounds(130, 228, 80, 15);
		contentPane.add(lblPassword);
		
		nom = new JTextField();
		nom.setBounds(190, 148, 158, 32);
		contentPane.add(nom);
		nom.setColumns(10);
		
		prenom = new JTextField();
		prenom.setBounds(190, 183, 158, 32);
		contentPane.add(prenom);
		prenom.setColumns(10);
		
		email = new JTextField();
		email.setBounds(190, 221, 158, 29);
		contentPane.add(email);
		email.setColumns(10);
		
		JButton Supprimer = new JButton("");
		Supprimer.setIcon(new ImageIcon("/home/zaki/eclipse-workspace/Gestion_materiel/images/supp.png"));
		Supprimer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String sql="delete from utilisateurs where username=? and password=?";
				try {
					prepared= cnx.prepareStatement(sql);
					prepared.setString(1, username.getText().toString());
					prepared.setString(2, passwor.getText().toString());
					prepared.execute();
					JOptionPane.showMessageDialog(null, "L'Utilisateur supprimé avec succès. 😜");
					passwor.setText("");
					username.setText("");
					nom.setText("");
					prenom.setText("");
					email.setText("");

					UpdateTable();//appel a la fct UpdateTable();
				
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		Supprimer.setBounds(248, 296, 46, 44);
		contentPane.add(Supprimer);
		
		JButton modifier = new JButton("");
		modifier.setIcon(new ImageIcon("/home/zaki/eclipse-workspace/Gestion_materiel/images/update.png"));
		modifier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//modifier
                String user= username.getText().toString();
				String sql="update utilisateurs set username=?,password=? where username='"+userold+"'";
				try {
					prepared=cnx.prepareStatement(sql);
					prepared.setString(1, user);
					prepared.setString(2, passwor.getText().toString());
					
				    
					String us=username.getText();
					String pa=passwor.getText();
					String noo=nom.getText();
					String pr=prenom.getText();
					String mai=email.getText();
					if(!us.equals("") && !pa.equals("") && !noo.equals("") && !pr.equals("") && !mai.equals("")) 
					{
					prepared.execute();		
					JOptionPane.showMessageDialog(null, "Utilisateur modifié avec succès. 😜");
					UpdateTable();//appel a la fct UpdateTable();
					}
					else {
						JOptionPane.showMessageDialog(null, "Remplissez les champs vides !! 😜");
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
		
				
			}
		});
		modifier.setBounds(298, 296, 46, 44);
		contentPane.add(modifier);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(490, 102, 498, 274);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//clicked
				int ligne=table.getSelectedRow();//une fois cliqué sur une ligne dans la table"ligne" reçoit le num de la ligne
				//JOptionPane.showMessageDialog(null, ligne);
				 userold= table.getModel().getValueAt(ligne, 0).toString();
				String no= table.getModel().getValueAt(ligne, 1).toString();
				String pren= table.getModel().getValueAt(ligne, 2).toString();
				String mail= table.getModel().getValueAt(ligne, 3).toString();
				String pass= table.getModel().getValueAt(ligne, 4).toString();
				username.setText( userold);
				nom.setText(no);
				prenom.setText(pren);
				email.setText(mail);
				passwor.setText(pass);
				
				
	
			}
		});
		scrollPane.setViewportView(table);
		
		JButton actualiser = new JButton("");
		actualiser.setIcon(new ImageIcon("/home/zaki/eclipse-workspace/Gestion_materiel/images/reset.png"));
		actualiser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//actualiser
				UpdateTable();//appel a la fct UpdateTable();
			}
		});
		actualiser.setBounds(948, 70, 40, 29);
		contentPane.add(actualiser);
		
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//back
				Menu_administrateur obj= new Menu_administrateur();
				obj.setVisible(true);
				obj.setLocationRelativeTo(null);
				fermer();
			}
		});
		btnNewButton_1.setIcon(new ImageIcon("/home/zaki/eclipse-workspace/Gestion_materiel/images/backok.png"));
		btnNewButton_1.setBounds(12, 99, 46, 32);
		contentPane.add(btnNewButton_1);
		
		JLabel lblListeUtilisateurs = new JLabel("Liste Utilisateurs:");
		lblListeUtilisateurs.setFont(new Font("Khmer OS System", Font.BOLD, 18));
		lblListeUtilisateurs.setBounds(490, 79, 164, 20);
		contentPane.add(lblListeUtilisateurs);
		
		JLabel lblNouvelUtilisateur = new JLabel("Nouvel Utilisateur:");
		lblNouvelUtilisateur.setFont(new Font("Khmer OS System", Font.BOLD, 18));
		lblNouvelUtilisateur.setBounds(186, 79, 172, 20);
		contentPane.add(lblNouvelUtilisateur);

		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("/home/zaki/eclipse-workspace/Gestion_materiel/images/logo2.png"));
		lblNewLabel.setBounds(-12, 0, 1012, 612);
		contentPane.add(lblNewLabel);
	}
	public void UpdateTable() {
		String sql= "select username,nom,prenom,email,password from utilisateurs";
		try {
			prepared= cnx.prepareStatement(sql);
			resultat=prepared.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(resultat));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
