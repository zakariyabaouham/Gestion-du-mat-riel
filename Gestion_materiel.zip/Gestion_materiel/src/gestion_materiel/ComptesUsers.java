package gestion_materiel;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import net.proteanit.sql.DbUtils;

import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;

import javax.swing.JComboBox;
import javax.swing.JFileChooser;

import com.toedter.calendar.JDateChooser;
import java.awt.Color;
import javax.swing.JList;
import java.awt.SystemColor;

public class ComptesUsers extends JFrame {

	private JPanel contentPane;
	String userold= null;
	private String s;
	JComboBox user_box ;
	JLabel lab_imgg ;

	//Creation des 3 objets de type Connection
		Connection cnx=null; // poyr établir la BD
		PreparedStatement prepared= null; //pr exécuter une requête	 
		ResultSet resultat= null; //récupération des infos de BD
		private JTextField affichage;
		private JTable table;
		private JTextField affix;
		//méthode pour fermer une fenêtre
		void fermer() {
			dispose();
		}
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ComptesUsers frame = new  ComptesUsers();
					frame.setVisible(true);
					//fixer la fenetre à la mm taille d'autres fenetres
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public  ComptesUsers() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1000, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		//établissement de la connexion DB
		cnx= connexionMysql.ConnexionDB();
	
		
		JLabel mat = new JLabel("Séléctionnez l'utilisateur concerné:");
		mat.setBounds(48, 141, 274, 32);
		contentPane.add(mat);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.setIcon(new ImageIcon("/home/zaki/eclipse-workspace/Gestion_materiel/images/ok/search.png"));
		btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				//String mat_box id_usr_box
			//		date_empr_box date_r_box duree_empr_box
					
					 userold= user_box.getSelectedItem().toString();
					 String sql="select  utilisateurs.nom,utilisateurs.prenom,utilisateurs.username, Materiel.photo, Materiel.nom, Emprunt.date_prendre, Emprunt.date_rendre, Emprunt.duree_reserv from utilisateurs, Materiel, Emprunt where Materiel.id_materiel_a_empr=Emprunt.id_materiel_a_empr AND utilisateurs.id_user=Emprunt.id_user AND username='"+userold+"'";
					 try {
						prepared =cnx.prepareStatement(sql);
						resultat= prepared.executeQuery();
						if(resultat.next())
						{
							//affichage.setText(resultat.getString("utilisateurs.username"+"utilisateurs.nom"));
							String nom= resultat.getString("utilisateurs.nom");
							String prenom= resultat.getString("utilisateurs.prenom");
							String date_prendre= resultat.getString("Emprunt.date_prendre");
							String date_rendre= resultat.getString("Emprunt.date_rendre");
							String duree_reserv= resultat.getString("Emprunt.duree_reserv");
							String mat_nom= resultat.getString("Materiel.nom");
							String u= resultat.getString("utilisateurs.username");
							affichage.setText("- "+nom+" "+prenom+" ("+u+")"+" a emprunté le matériel suivant:");
							affix.setText("- "+mat_nom+" du "+date_prendre+" au "+date_rendre);
							
						
							
							
							//récupération de l'image a partir de la BD
							
							byte[] img= resultat.getBytes("Materiel.photo");
							ImageIcon image= new ImageIcon(img);
							Image im=image.getImage();
							Image myImg=im.getScaledInstance(lab_imgg.getWidth(), lab_imgg.getHeight(), Image.SCALE_SMOOTH);
							ImageIcon imgg=new ImageIcon(myImg);
							lab_imgg.setIcon(imgg);
							
						}
						
						
			
					 } catch(SQLException e1) {
						 e1.printStackTrace();
					 }
					
					
				}
					//String sql="insert into utilisateurs(username,nom,prenom,email,password) values (?, ?, ?, ?, ?)"; // réquete insert
			
		
		});
		
		JLabel lblNewLabel_1 = new JLabel("Résultat de la Recherche:");
		lblNewLabel_1.setFont(new Font("Khmer OS System", Font.BOLD, 18));
		lblNewLabel_1.setBounds(399, 75, 274, 45);
		contentPane.add(lblNewLabel_1);
		btnNewButton.setBounds(148, 208, 53, 45);
		contentPane.add(btnNewButton);
		
//		///debut
			JPanel panel = new JPanel();
			panel.setBounds(851, 114, 137, 236);
			contentPane.add(panel);
			panel.setLayout(new GridLayout(1, 1));
			
			lab_imgg = new JLabel("");
			panel.add(lab_imgg);
		
		 JLabel lab_imgg1;
		
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//back
				Menu_administrateur obj= new Menu_administrateur();
				obj.setVisible(true);
				obj.setLocationRelativeTo(null);
				fermer();
			}
		});
		btnNewButton_1.setIcon(new ImageIcon("/home/zaki/eclipse-workspace/Gestion_materiel/images/backok.png"));
		btnNewButton_1.setBounds(12, 70, 46, 32);
		contentPane.add(btnNewButton_1);
		
		JLabel lblRetourDeMatriel = new JLabel("Lister les emprunts d'un utilisateur particulier.");
		lblRetourDeMatriel.setBounds(22, 105, 359, 37);
		contentPane.add(lblRetourDeMatriel);
		lblRetourDeMatriel.setFont(new Font("Khmer OS System", Font.BOLD, 15));
		
		affichage = new JTextField();
		affichage.setForeground(SystemColor.activeCaption);
		affichage.setEditable(false);
		affichage.setFont(new Font("Khmer OS System", Font.BOLD, 13));
		affichage.setBounds(399, 114, 440, 45);
		contentPane.add(affichage);
		affichage.setColumns(10);
		
		user_box = new JComboBox();
		user_box.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				
			
				
			}
		});
		user_box.setBounds(68, 171, 222, 29);
		contentPane.add(user_box);
		//appell a la fct remplirComboxUser()
				remplirComboxUser();
		
		JLabel lblNewLabel_2 = new JLabel("NB: Seulement la liste des utilisateurs qui ont ");
		lblNewLabel_2.setFont(new Font("Dyuthi", Font.BOLD, 16));
		lblNewLabel_2.setForeground(Color.RED);
		lblNewLabel_2.setBounds(20, 285, 381, 15);
		contentPane.add(lblNewLabel_2);
		
		affix = new JTextField();
		affix.setForeground(SystemColor.activeCaption);
		affix.setEditable(false);
		affix.setFont(new Font("Khmer OS System", Font.BOLD, 13));
		affix.setColumns(10);
		affix.setBounds(399, 171, 440, 45);
		contentPane.add(affix);
		
		JLabel lblEmpruntUnMatriel = new JLabel("emprunté un matériel qui sera s'affichée.");
		lblEmpruntUnMatriel.setForeground(Color.RED);
		lblEmpruntUnMatriel.setFont(new Font("Dyuthi", Font.BOLD, 16));
		lblEmpruntUnMatriel.setBounds(48, 299, 381, 15);
		contentPane.add(lblEmpruntUnMatriel);
		
	

		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("/home/zaki/eclipse-workspace/Gestion_materiel/images/nouvel_emprunt.png"));
		lblNewLabel.setBounds(-12, 0, 1012, 612);
		contentPane.add(lblNewLabel);
		
		 JLabel lab_img = new JLabel("");
		 lab_img.setBounds(256, 131, 145, 122);
		 contentPane.add(lab_img);
		 
		 table = new JTable();
		 table.setBounds(137, 178, 1, 1);
		 contentPane.add(table);
	}
	
	//remplircomboxUser
		public void remplirComboxUser() {
			String sql="select username from utilisateurs where id_user in (select Emprunt.id_user from Emprunt, utilisateurs where utilisateurs.id_user=Emprunt.id_user)";
			try {
				prepared = cnx.prepareStatement(sql);
				resultat= prepared.executeQuery();
				while(resultat.next()) {
					String no=resultat.getString("username").toString();
					user_box.addItem(no);
					
					
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
}
